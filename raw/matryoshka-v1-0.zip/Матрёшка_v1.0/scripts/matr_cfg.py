"""Матрёшка: чтение МОИ_СЕРВЕРЫ.txt. Пароли никуда не печатаются."""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.environ.get("MATR_ROOT") or os.path.dirname(HERE)
CFG_FILE = os.path.join(ROOT, "МОИ_СЕРВЕРЫ.txt")
OUT_DIR = os.path.join(ROOT, "МОИ_КОНФИГИ")

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def read_cfg():
    if not os.path.exists(CFG_FILE):
        sys.exit(f"Нет файла {CFG_FILE}. Его заполняет человек: адреса и пароли серверов.")
    cfg = {}
    with open(CFG_FILE, encoding="utf-8-sig") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, val = line.split("=", 1)
            cfg[key.strip().upper()] = val.strip()
    return cfg


def need(cfg, key, human):
    val = cfg.get(key, "")
    if not val or val.startswith("<"):
        sys.exit(f"В МОИ_СЕРВЕРЫ.txt не заполнено: {key} ({human}). Попроси человека вписать и сохранить файл.")
    return val


def secrets(cfg):
    """Всё, что нельзя показывать: пароли из файла."""
    return [v for k, v in cfg.items() if ("ПАРОЛЬ" in k or "PASSWORD" in k) and len(v) >= 3]


def hide(text, cfg):
    for s in secrets(cfg):
        text = text.replace(s, "<скрыто>")
    return text
