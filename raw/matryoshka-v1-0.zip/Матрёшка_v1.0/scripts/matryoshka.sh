#!/usr/bin/env bash
# =====================================================================
#  МАТРЁШКА v1.0 — каскад VPN на AmneziaWG
#
#    роутер / телефон  ->  ВХОД (сервер в РФ)  ->  ВЫХОД (сервер за границей)  ->  интернет
#
#  Российские адреса (ВК, банки, госуслуги) выходят в интернет с ВХОДА,
#  всё остальное — с ВЫХОДА. Выход не видит никто, кроме входа.
#  Упал выход — клиенты остаются без интернета (стоп-кран), а не идут напрямую.
#
#  Запуск только от root. Подкоманды:
#    exit               настроить ВЫХОД   (нужно ENTRY_IP=<адрес входа>)
#    entry              настроить ВХОД    (нужен /root/matryoshka/entry-uplink.conf с выхода)
#    status             проверка (на любом из двух)
#    add-client ИМЯ     ещё один клиент на входе -> /root/matryoshka/clients/ИМЯ.conf
#    set-entry-ip IP    на выходе: сменить адрес входа, которому открыт порт
#    ru-update          на входе: обновить список российских сетей (сам — раз в неделю)
#    heal               на входе: переприменить правила (сам — раз в минуту)
#    remove             снести всё, что поставила матрёшка
# =====================================================================
set -eu
export DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a NEEDRESTART_SUSPEND=1 LC_ALL=C.UTF-8

DIR=/root/matryoshka            # рабочая папка (ключ связки, конфиги клиентов)
CONF=/etc/amnezia/amneziawg     # конфиги туннелей
STATE=/etc/matryoshka           # настройки матрёшки
UP_NET=10.71.0                  # сеть «вход <-> выход»
CL_NET=10.70.0                  # сеть «клиенты <-> вход»
TABLE=300                       # таблица маршрутов «всё через выход»
MARK=0x1                        # метка «российский адрес — напрямую с входа»
APT="apt-get -y -q -o DPkg::Lock::Timeout=900"
# I1 — «маскировочный» первый пакет (похож на ответ DNS). Только на связке вход<->выход.
I1_PACKET='<r 2><b 0x858000010001000000000669636c6f756403636f6d0000010001c00c000100010000105a00044d583737>'
SELF=$(readlink -f "$0")

say() { printf '\n=== %s\n' "$*"; }
ok()  { printf 'OK: %s\n' "$*"; }
warn(){ printf 'ВНИМАНИЕ: %s\n' "$*"; }
die() { printf 'ОШИБКА: %s\n' "$*" >&2; exit 1; }

rnd() { # rnd MIN MAX — случайное целое
  local r; r=$(od -An -N4 -tu4 /dev/urandom | tr -d ' \n')
  echo $(( $1 + r % ($2 - $1 + 1) ))
}

wan_if() { ip -4 route show default | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}'; }

public_ip() {
  curl -4 -fsS --max-time 8 https://api.ipify.org 2>/dev/null \
  || curl -4 -fsS --max-time 8 https://ifconfig.me 2>/dev/null \
  || ip -4 route get 1.1.1.1 | awk '{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}'
}

port_busy() { [ -n "$(ss -Hlun "sport = :$1" 2>/dev/null)" ]; }

# ---------------------------------------------------------------- подготовка
check_platform() {
  [ "$(id -u)" = 0 ] || die "нужен root"
  local id pretty virt
  id=$(. /etc/os-release 2>/dev/null; echo "${ID:-}")
  pretty=$(. /etc/os-release 2>/dev/null; echo "${PRETTY_NAME:-неизвестно}")
  case "$id" in
    ubuntu|debian) ok "система: $pretty" ;;
    *) die "нужен Debian 11–13 или Ubuntu 22.04/24.04 (лучше Debian 13), а тут: $pretty" ;;
  esac
  virt=$(systemd-detect-virt 2>/dev/null) || true
  [ -n "$virt" ] || virt=unknown
  case "$virt" in
    openvz|lxc|lxc-libvirt) warn "виртуализация $virt: модуль ядра не встанет, будет вариант без ядра (медленнее)" ;;
    *) ok "виртуализация: $virt" ;;
  esac
  [ -c /dev/net/tun ] || warn "нет /dev/net/tun: если не встанет модуль ядра, туннель не заработает (попроси хостера KVM)"
  ip -4 route show default 2>/dev/null | grep -q .     || die "у сервера НЕТ IPv4 (только IPv6). Роутеры и российские сайты работают по IPv4: добавь IPv4 в панели хостера или возьми тариф с IPv4"
}

ensure_swap() {
  local mem swap
  mem=$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo)
  swap=$(awk '/SwapTotal/{print int($2/1024)}' /proc/meminfo)
  if [ "$mem" -lt 1500 ] && [ "$swap" -lt 512 ] && [ ! -e /swapfile ]; then
    { fallocate -l 1G /swapfile 2>/dev/null || dd if=/dev/zero of=/swapfile bs=1M count=1024 status=none; } \
      && chmod 600 /swapfile && mkswap /swapfile >/dev/null && swapon /swapfile \
      && echo '/swapfile none swap sw 0 0' >> /etc/fstab && ok "добавил 1 ГБ подкачки (памяти ${mem} МБ)" \
      || warn "подкачку добавить не вышло, иду дальше"
  fi
}

sysctl_setup() {
  modprobe tcp_bbr 2>/dev/null || true
  cat > /etc/sysctl.d/90-matryoshka.conf <<'EOF'
# Матрёшка: пересылка пакетов, IPv6 выключен целиком (никаких утечек мимо туннеля), BBR
net.ipv4.ip_forward = 1
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOF
  sysctl --system >/dev/null 2>&1 || true
  [ "$(cat /proc/sys/net/ipv4/ip_forward)" = 1 ] || die "не включилась пересылка пакетов (ip_forward)"
  ok "пересылка включена, IPv6 выключен"
}

networkd_keep() {
  # systemd-networkd при своём перезапуске сносит «чужие» правила маршрутизации. Запрещаем.
  mkdir -p /etc/systemd/networkd.conf.d
  printf '[Network]\nManageForeignRoutingPolicyRules=no\nManageForeignRoutes=no\n' \
    > /etc/systemd/networkd.conf.d/10-matryoshka.conf
}

apt_sources_fix() {
  # Debian 9-11: поддержка кончилась, обновления переехали на archive.debian.org — иначе apt ловит 404
  local id code f
  id=$(. /etc/os-release 2>/dev/null; echo "${ID:-}")
  code=$(. /etc/os-release 2>/dev/null; echo "${VERSION_CODENAME:-}")
  [ "$id" = debian ] || return 0
  case "$code" in stretch|buster|bullseye) ;; *) return 0 ;; esac
  grep -qs 'archive.debian.org/debian-security' /etc/apt/sources.list && return 0
  warn "Debian $code: поддержка закончилась, обновления лежат в архиве — переключаю источники на archive.debian.org"
  echo 'Acquire::Check-Valid-Until "false";' > /etc/apt/apt.conf.d/99matryoshka-archive
  for f in /etc/apt/sources.list /etc/apt/sources.list.d/*.list; do
    [ -f "$f" ] || continue
    [ -e "$f.matr-bak" ] || cp "$f" "$f.matr-bak"
    sed -i -E -e 's#^deb-src #\# deb-src #'       -e 's#https?://security\.debian\.org(/debian-security)?/?#http://archive.debian.org/debian-security/#g' "$f"
  done
  if [ "$code" != bullseye ] || ! $APT update >/dev/null 2>&1; then
    for f in /etc/apt/sources.list /etc/apt/sources.list.d/*.list; do
      [ -f "$f" ] || continue
      sed -i -E 's#^(deb[[:space:]]+)https?://[^[:space:]]+/debian/?([[:space:]])#\1http://archive.debian.org/debian/\2#' "$f"
    done
  fi
  ok "источники пакетов: архив Debian"
}

base_setup() {
  say "Подготовка сервера"
  check_platform
  apt_sources_fix
  $APT update >/dev/null
  $APT install curl ca-certificates iproute2 nftables python3 >/dev/null
  ensure_swap
  sysctl_setup
  mkdir -p "$DIR" "$CONF" "$STATE"
  chmod 700 "$DIR" "$CONF" "$STATE"
  if [ "$SELF" != /usr/local/sbin/matryoshka ]; then install -m 0755 "$SELF" /usr/local/sbin/matryoshka; fi
  if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
    warn "включён ufw — он может резать туннель. Если не будет связи: ufw disable"
  fi
}

# ---------------------------------------------------------------- AmneziaWG
awg_ready() {
  command -v awg >/dev/null 2>&1 && command -v awg-quick >/dev/null 2>&1 || return 1
  modprobe amneziawg 2>/dev/null && return 0
  command -v amneziawg-go >/dev/null 2>&1
}

build_tools() {
  say "Собираю amneziawg-tools из исходников"
  $APT install git make gcc libc6-dev >/dev/null
  rm -rf /opt/matryoshka-src/amneziawg-tools
  git clone -q --depth 1 https://github.com/amnezia-vpn/amneziawg-tools /opt/matryoshka-src/amneziawg-tools
  make -s -C /opt/matryoshka-src/amneziawg-tools/src >/dev/null
  make -s -C /opt/matryoshka-src/amneziawg-tools/src install WITH_WGQUICK=yes WITH_SYSTEMDUNITS=yes WITH_BASHCOMPLETION=no >/dev/null
}

install_go() {
  if [ -x /usr/local/go/bin/go ]; then return 0; fi
  local v arch
  arch=$(dpkg --print-architecture)
  v=$(curl -fsS --max-time 15 'https://go.dev/VERSION?m=text' 2>/dev/null | head -1 || true)
  case "$v" in go1.*) ;; *) v=go1.25.0 ;; esac
  curl -fsSL --retry 3 --max-time 900 -o /tmp/go.tgz "https://go.dev/dl/${v}.linux-${arch}.tar.gz" \
    || curl -fsSL --retry 3 --max-time 900 -o /tmp/go.tgz "https://dl.google.com/go/${v}.linux-${arch}.tar.gz" \
    || die "не скачался Go (нужен для сборки amneziawg-go)"
  rm -rf /usr/local/go && tar -C /usr/local -xzf /tmp/go.tgz && rm -f /tmp/go.tgz
}

build_go() {
  say "Модуля ядра нет — собираю amneziawg-go (5–10 минут, это нормально)"
  $APT install git make gcc libc6-dev >/dev/null
  install_go
  export PATH=/usr/local/go/bin:$PATH
  rm -rf /opt/matryoshka-src/amneziawg-go
  git clone -q --depth 1 https://github.com/amnezia-vpn/amneziawg-go /opt/matryoshka-src/amneziawg-go
  ( cd /opt/matryoshka-src/amneziawg-go && { make >/dev/null 2>&1 || go build -o amneziawg-go . ; } )
  install -m 0755 /opt/matryoshka-src/amneziawg-go/amneziawg-go /usr/local/bin/amneziawg-go
  ok "amneziawg-go собран"
}

install_awg() {
  if awg_ready; then ok "AmneziaWG уже стоит"; return 0; fi
  local id; id=$(. /etc/os-release 2>/dev/null; echo "${ID:-}")
  if [ "$id" = ubuntu ]; then
    say "Ставлю AmneziaWG из официального PPA Amnezia (модуль ядра)"
    $APT install software-properties-common >/dev/null
    $APT install "linux-headers-$(uname -r)" >/dev/null 2>&1 || warn "заголовки ядра $(uname -r) не нашлись"
    add-apt-repository -y ppa:amnezia/ppa >/dev/null 2>&1 || warn "PPA не добавился"
    $APT update >/dev/null 2>&1 || true
    $APT install amneziawg >/dev/null 2>&1 || warn "пакет amneziawg не встал"
    if modprobe amneziawg 2>/dev/null; then
      echo amneziawg > /etc/modules-load.d/amneziawg.conf
      ok "модуль ядра amneziawg загружен (самый быстрый вариант)"
    fi
  fi
  if ! command -v awg >/dev/null 2>&1 || ! command -v awg-quick >/dev/null 2>&1; then build_tools; fi
  if ! modprobe amneziawg 2>/dev/null; then build_go; fi
  awg_ready || die "AmneziaWG не встал. Пришли последние 40 строк вывода"
  ok "AmneziaWG готов"
}

# ---------------------------------------------------------------- параметры маскировки
gen_params() {
  # Классический набор AmneziaWG (Jc, Jmin, Jmax, S1, S2, H1-H4): его понимают
  # и стабильные прошивки Keenetic, и приложение AmneziaVPN, и любые серверы.
  JC=$(rnd 3 8); JMIN=$(rnd 30 60); JMAX=$(( JMIN + $(rnd 30 200) ))
  S1=$(rnd 15 120); S2=$(rnd 15 120)
  while [ $(( S1 + 56 )) -eq "$S2" ]; do S2=$(rnd 15 120); done
  local seen=" " h i
  for i in 1 2 3 4; do
    while :; do
      h=$(rnd 5 2147483647)
      case "$seen" in *" $h "*) ;; *) break ;; esac
    done
    seen="$seen$h "
    eval "H$i=$h"
  done
}

asc_lines() {
  printf 'Jc = %s\nJmin = %s\nJmax = %s\nS1 = %s\nS2 = %s\nH1 = %s\nH2 = %s\nH3 = %s\nH4 = %s\n' \
    "$JC" "$JMIN" "$JMAX" "$S1" "$S2" "$H1" "$H2" "$H3" "$H4"
}

save_params() { # save_params FILE
  printf 'JC=%s\nJMIN=%s\nJMAX=%s\nS1=%s\nS2=%s\nH1=%s\nH2=%s\nH3=%s\nH4=%s\n' \
    "$JC" "$JMIN" "$JMAX" "$S1" "$S2" "$H1" "$H2" "$H3" "$H4" > "$1"
  chmod 600 "$1"
}

start_iface() { # start_iface ИМЯ
  local n=$1
  systemctl enable "awg-quick@$n" >/dev/null 2>&1 || true
  if systemctl restart "awg-quick@$n"; then ok "туннель $n поднят"; return 0; fi
  if grep -q '^I1' "$CONF/$n.conf"; then
    warn "эта версия AmneziaWG не знает I1 — убираю I1 на этой стороне (второй стороне это не мешает)"
    sed -i '/^I[1-5] *=/d' "$CONF/$n.conf"
    if systemctl restart "awg-quick@$n"; then ok "туннель $n поднят (без I1)"; return 0; fi
  fi
  journalctl -u "awg-quick@$n" -n 30 --no-pager || true
  die "туннель $n не поднялся"
}

# ---------------------------------------------------------------- ВЫХОД
fw_exit_load() {
  # shellcheck disable=SC1091
  . "$STATE/exit.env"
  nft delete table inet matr_exit 2>/dev/null || true
  nft -f - <<EOF
table inet matr_exit {
  chain input {
    type filter hook input priority -10; policy accept;
    udp dport $PORT ip saddr != $ENTRY_IP drop
  }
  chain forward {
    type filter hook forward priority -10; policy accept;
    tcp flags syn tcp option maxseg size set rt mtu
    iifname "awgx" oifname "$WAN" accept
    iifname "$WAN" oifname "awgx" ct state established,related accept
    iifname "awgx" drop
    oifname "awgx" drop
  }
  chain post {
    type nat hook postrouting priority srcnat; policy accept;
    ip saddr $UP_NET.0/24 oifname "$WAN" masquerade
  }
}
EOF
}

cmd_exit() {
  local entry_ip=${ENTRY_IP:-} exit_ip=${EXIT_IP:-} port wan spriv spub cpriv cpub psk
  [ -n "$entry_ip" ] || die "передай ENTRY_IP=<адрес входного сервера>"
  if [ -f "$CONF/awgx.conf" ] && [ -z "${FORCE:-}" ]; then
    die "выход уже настроен. Перенастроить с нуля (старая связка перестанет работать): FORCE=1"
  fi
  base_setup
  install_awg
  say "Настраиваю ВЫХОД"
  [ -n "$exit_ip" ] || exit_ip=$(public_ip)
  wan=$(wan_if); [ -n "$wan" ] || die "не нашёл сетевую карту с интернетом"
  port=${EXIT_PORT:-$(rnd 20000 60000)}
  while port_busy "$port"; do port=$(rnd 20000 60000); done
  spriv=$(awg genkey); spub=$(printf '%s' "$spriv" | awg pubkey)
  cpriv=$(awg genkey); cpub=$(printf '%s' "$cpriv" | awg pubkey)
  psk=$(awg genpsk)
  gen_params
  umask 077
  {
    printf '[Interface]\nPrivateKey = %s\nAddress = %s.1/24\nListenPort = %s\nMTU = 1380\n' "$spriv" "$UP_NET" "$port"
    asc_lines
    printf 'I1 = %s\n' "$I1_PACKET"
    printf 'PostUp = /usr/local/sbin/matryoshka fw-exit\n'
    printf '\n[Peer]\n# вход\nPublicKey = %s\nPresharedKey = %s\nAllowedIPs = %s.2/32\n' "$cpub" "$psk" "$UP_NET"
  } > "$CONF/awgx.conf"
  {
    printf '[Interface]\nPrivateKey = %s\nAddress = %s.2/32\nMTU = 1380\nTable = off\n' "$cpriv" "$UP_NET"
    asc_lines
    printf 'I1 = %s\n' "$I1_PACKET"
    printf '\n[Peer]\nPublicKey = %s\nPresharedKey = %s\nEndpoint = %s:%s\nAllowedIPs = 0.0.0.0/0\nPersistentKeepalive = 25\n' \
      "$spub" "$psk" "$exit_ip" "$port"
  } > "$DIR/entry-uplink.conf"
  printf 'ENTRY_IP=%s\nPORT=%s\nWAN=%s\nEXIT_IP=%s\n' "$entry_ip" "$port" "$wan" "$exit_ip" > "$STATE/exit.env"
  start_iface awgx
  ok "выход слушает порт $port/udp и пускает только вход $entry_ip"
  ok "ключ связки для входа: $DIR/entry-uplink.conf (перенести на вход в ту же папку)"
}

cmd_set_entry_ip() {
  local ip=${1:-}
  [ -f "$STATE/exit.env" ] || die "это не выход"
  case "$ip" in *.*.*.*) ;; *) die "дай адрес: set-entry-ip 1.2.3.4" ;; esac
  sed -i "s/^ENTRY_IP=.*/ENTRY_IP=$ip/" "$STATE/exit.env"
  fw_exit_load
  ok "порт выхода теперь открыт для $ip"
}

# ---------------------------------------------------------------- ВХОД
fw_entry_load() {
  # shellcheck disable=SC1091
  . "$STATE/entry.env"
  nft delete table inet matr_entry 2>/dev/null || true
  nft -f - <<EOF
table inet matr_entry {
  set ru4 { type ipv4_addr; flags interval; auto-merge; }
  set private4 {
    type ipv4_addr; flags interval;
    elements = { 0.0.0.0/8, 10.0.0.0/8, 100.64.0.0/10, 127.0.0.0/8, 169.254.0.0/16,
                 172.16.0.0/12, 192.168.0.0/16, 224.0.0.0/4, 240.0.0.0/4 }
  }
  chain pre {
    type filter hook prerouting priority mangle; policy accept;
    iifname "awgc" ip daddr @ru4 meta mark set $MARK
  }
  chain input {
    type filter hook input priority -10; policy accept;
    iifname "awgc" ct state established,related accept
    iifname "awgc" icmp type echo-request accept
    iifname "awgc" drop
  }
  chain forward {
    type filter hook forward priority -10; policy accept;
    tcp flags syn tcp option maxseg size set rt mtu
    iifname "awgc" ip daddr @private4 drop
    iifname "awgc" oifname "awgx" accept
    iifname "awgc" oifname "$WAN" meta mark $MARK accept
    iifname { "awgx", "$WAN" } oifname "awgc" ct state established,related accept
    iifname "awgc" drop
    oifname "awgc" drop
  }
  chain post {
    type nat hook postrouting priority srcnat; policy accept;
    oifname "awgx" masquerade
    ip saddr $CL_NET.0/24 oifname "$WAN" masquerade
  }
}
EOF
}

load_ru_set() {
  [ -s "$STATE/ru4.txt" ] || return 0
  { echo "flush set inet matr_entry ru4"
    echo "add element inet matr_entry ru4 {"
    sed '$!s/$/,/' "$STATE/ru4.txt"
    echo "}"
  } > /tmp/matryoshka-ru4.nft
  nft -f /tmp/matryoshka-ru4.nft && rm -f /tmp/matryoshka-ru4.nft
}

cmd_ru_update() {
  local tmp n src=""
  tmp=$(mktemp)
  if curl -fsS --max-time 60 -o "$tmp" https://www.ipdeny.com/ipblocks/data/aggregated/ru-aggregated.zone 2>/dev/null \
     && [ "$(grep -cE '^[0-9.]+/[0-9]+$' "$tmp")" -gt 1000 ]; then
    src=ipdeny
  elif curl -fsS --max-time 90 'https://stat.ripe.net/data/country-resource-list/data.json?resource=RU&v4_format=prefix' 2>/dev/null \
       | python3 -c 'import sys,json; print("\n".join(json.load(sys.stdin)["data"]["resources"]["ipv4"]))' > "$tmp" 2>/dev/null \
       && [ "$(grep -cE '^[0-9.]+/[0-9]+$' "$tmp")" -gt 1000 ]; then
    src=RIPE
  fi
  if [ -z "$src" ]; then
    rm -f "$tmp"
    warn "список российских сетей не скачался — оставляю старый"
    return 0
  fi
  grep -E '^[0-9.]+/[0-9]+$' "$tmp" > "$STATE/ru4.txt"; rm -f "$tmp"
  n=$(wc -l < "$STATE/ru4.txt")
  if nft list table inet matr_entry >/dev/null 2>&1; then load_ru_set; fi
  ok "российских сетей в списке: $n (источник: $src) — они идут напрямую с входа"
}

cmd_heal() {
  [ -f "$STATE/entry.env" ] || exit 0
  if ! nft list table inet matr_entry >/dev/null 2>&1; then fw_entry_load; load_ru_set; fi
  ip route replace unreachable default metric 9999 table "$TABLE" 2>/dev/null || true
  if ip link show awgx >/dev/null 2>&1; then ip route replace default dev awgx table "$TABLE"; fi
  ip rule show | grep -q '^1000:' || ip rule add pref 1000 iif awgc fwmark "$MARK" lookup main
  ip rule show | grep -q '^1100:' || ip rule add pref 1100 iif awgc lookup "$TABLE"
}

add_client() { # add_client ИМЯ [noreload]
  local name=$1 mode=${2:-} n cpriv cpub psk
  case "$name" in *[!A-Za-z0-9_-]*|"") die "имя клиента — только латиница, цифры, - и _" ;; esac
  [ -e "$DIR/clients/$name.conf" ] && die "клиент $name уже есть"
  # shellcheck disable=SC1091
  . "$STATE/entry.env"
  # shellcheck disable=SC1091
  . "$STATE/awgc.params"
  n=2
  while grep -q "AllowedIPs = $CL_NET.$n/32" "$CONF/awgc.conf"; do n=$((n + 1)); done
  [ "$n" -le 250 ] || die "кончились адреса"
  cpriv=$(awg genkey); cpub=$(printf '%s' "$cpriv" | awg pubkey); psk=$(awg genpsk)
  printf '\n[Peer]\n# %s\nPublicKey = %s\nPresharedKey = %s\nAllowedIPs = %s.%s/32\n' \
    "$name" "$cpub" "$psk" "$CL_NET" "$n" >> "$CONF/awgc.conf"
  mkdir -p "$DIR/clients"; chmod 700 "$DIR/clients"
  umask 077
  {
    printf '[Interface]\nPrivateKey = %s\nAddress = %s.%s/32\nDNS = 1.1.1.1, 9.9.9.9\nMTU = 1280\n' "$cpriv" "$CL_NET" "$n"
    asc_lines
    printf '\n[Peer]\nPublicKey = %s\nPresharedKey = %s\nEndpoint = %s:%s\nAllowedIPs = 0.0.0.0/0\nPersistentKeepalive = 25\n' \
      "$SPUB" "$psk" "$ENTRY_IP" "$CLIENT_PORT"
  } > "$DIR/clients/$name.conf"
  if [ "$mode" != noreload ] && ip link show awgc >/dev/null 2>&1; then
    awg syncconf awgc <(awg-quick strip awgc)
  fi
  ok "клиент $name ($CL_NET.$n): $DIR/clients/$name.conf"
}

install_units() {
  cat > /etc/systemd/system/matryoshka-heal.service <<'EOF'
[Unit]
Description=Matryoshka: re-apply routing rules
[Service]
Type=oneshot
ExecStart=/usr/local/sbin/matryoshka heal
EOF
  cat > /etc/systemd/system/matryoshka-heal.timer <<'EOF'
[Unit]
Description=Matryoshka: re-apply routing rules every minute
[Timer]
OnBootSec=30
OnUnitActiveSec=60
[Install]
WantedBy=timers.target
EOF
  cat > /etc/systemd/system/matryoshka-ru.service <<'EOF'
[Unit]
Description=Matryoshka: refresh list of Russian networks
After=network-online.target
[Service]
Type=oneshot
ExecStart=/usr/local/sbin/matryoshka ru-update
EOF
  cat > /etc/systemd/system/matryoshka-ru.timer <<'EOF'
[Unit]
Description=Matryoshka: refresh list of Russian networks weekly
[Timer]
OnCalendar=weekly
Persistent=true
[Install]
WantedBy=timers.target
EOF
  systemctl daemon-reload
  systemctl enable --now matryoshka-heal.timer matryoshka-ru.timer >/dev/null 2>&1
}

cmd_entry() {
  local entry_ip=${ENTRY_IP:-} port wan spriv spub
  [ -s "$DIR/entry-uplink.conf" ] || die "нет $DIR/entry-uplink.conf — его делает 'exit' на выходе, перенеси файл сюда"
  if [ -f "$CONF/awgc.conf" ] && [ -z "${FORCE:-}" ]; then
    die "вход уже настроен. Перенастроить с нуля (все старые конфиги клиентов умрут): FORCE=1"
  fi
  base_setup
  install_awg
  networkd_keep
  say "Настраиваю ВХОД"
  [ -n "$entry_ip" ] || entry_ip=$(public_ip)
  wan=$(wan_if); [ -n "$wan" ] || die "не нашёл сетевую карту с интернетом"
  umask 077
  # связка с выходом: свой маршрут в таблице 300, общий интернет сервера не трогаем (Table = off)
  awk '{print} /^\[Interface\]/{print "PostUp = /usr/local/sbin/matryoshka heal"}' \
    "$DIR/entry-uplink.conf" > "$CONF/awgx.conf"
  # туннель для клиентов (роутер, телефон, комп)
  port=${CLIENT_PORT:-443}
  if port_busy "$port"; then port=$(rnd 20000 60000); while port_busy "$port"; do port=$(rnd 20000 60000); done; fi
  spriv=$(awg genkey); spub=$(printf '%s' "$spriv" | awg pubkey)
  gen_params
  save_params "$STATE/awgc.params"
  printf 'ENTRY_IP=%s\nCLIENT_PORT=%s\nWAN=%s\nSPUB=%s\n' "$entry_ip" "$port" "$wan" "$spub" > "$STATE/entry.env"
  {
    printf '[Interface]\nPrivateKey = %s\nAddress = %s.1/24\nListenPort = %s\nMTU = 1280\n' "$spriv" "$CL_NET" "$port"
    asc_lines
    printf 'PostUp = /usr/local/sbin/matryoshka heal\n'
  } > "$CONF/awgc.conf"
  rm -rf "$DIR/clients"
  local c
  for c in ${CLIENTS:-keenetic phone pc}; do add_client "$c" noreload; done
  fw_entry_load
  cmd_ru_update
  install_units
  start_iface awgx
  start_iface awgc
  cmd_heal
  ok "вход слушает порт $port/udp"
  cmd_status
}

# ---------------------------------------------------------------- проверка
cmd_status() {
  say "Матрёшка на $(hostname): проверка"
  local i hs
  for i in awgx awgc; do
    ip link show "$i" >/dev/null 2>&1 || continue
    echo "-- туннель $i: $(awg show "$i" peers | wc -l) собеседник(ов)"
    awg show "$i" latest-handshakes | while read -r _ hs; do
      if [ "${hs:-0}" -gt 0 ]; then echo "   последнее рукопожатие: $(( $(date +%s) - hs )) с назад"
      else echo "   рукопожатия ещё не было"; fi
    done
  done
  if [ -f "$STATE/exit.env" ]; then
    # shellcheck disable=SC1091
    . "$STATE/exit.env"
    echo "-- это ВЫХОД: порт $PORT/udp открыт только для входа $ENTRY_IP"
  fi
  if [ -f "$STATE/entry.env" ]; then
    # shellcheck disable=SC1091
    . "$STATE/entry.env"
    local direct via
    direct=$(curl -4 -fsS --max-time 8 https://api.ipify.org 2>/dev/null || echo "нет ответа")
    via=$(curl -4 -fsS --max-time 12 --interface awgx https://api.ipify.org 2>/dev/null || echo "НЕТ ОТВЕТА — связка с выходом не работает")
    echo "-- это ВХОД"
    echo "   российские сайты видят адрес:   $direct"
    echo "   весь остальной мир видит адрес: $via"
    echo "   российских сетей в списке:      $(wc -l < "$STATE/ru4.txt" 2>/dev/null || echo 0)"
    if ip route show table "$TABLE" | grep -q unreachable; then
      echo "   стоп-кран: включён (упал выход — у клиентов нет интернета, а не прямой выход)"
    else
      echo "   стоп-кран: НЕ ВКЛЮЧЁН — запусти: matryoshka heal"
    fi
    echo "   клиенты: $(ls "$DIR/clients" 2>/dev/null | tr '\n' ' ')"
  fi
}

cmd_remove() {
  say "Сношу матрёшку"
  local i
  for i in awgc awgx; do systemctl disable --now "awg-quick@$i" >/dev/null 2>&1 || true; done
  systemctl disable --now matryoshka-heal.timer matryoshka-ru.timer >/dev/null 2>&1 || true
  rm -f /etc/systemd/system/matryoshka-heal.* /etc/systemd/system/matryoshka-ru.*
  systemctl daemon-reload
  nft delete table inet matr_entry 2>/dev/null || true
  nft delete table inet matr_exit 2>/dev/null || true
  ip rule del pref 1000 2>/dev/null || true
  ip rule del pref 1100 2>/dev/null || true
  ip route flush table "$TABLE" 2>/dev/null || true
  local bak; bak=/root/matryoshka-removed-$(date +%Y%m%d-%H%M%S)
  mkdir -p "$bak"
  for i in awgx awgc; do [ -f "$CONF/$i.conf" ] && mv "$CONF/$i.conf" "$bak/"; done
  [ -d "$STATE" ] && mv "$STATE" "$bak/state"
  ok "снесено; старые файлы лежат в $bak"
}

usage() { sed -n '2,24p' "$SELF"; }

case "${1:-}" in
  exit)          cmd_exit ;;
  entry)         cmd_entry ;;
  status)        cmd_status ;;
  add-client)    add_client "${2:-}" ;;
  set-entry-ip)  cmd_set_entry_ip "${2:-}" ;;
  ru-update)     cmd_ru_update ;;
  heal)          cmd_heal ;;
  fw-exit)       fw_exit_load ;;
  prep)          base_setup ;;
  remove)        cmd_remove ;;
  *)             usage ;;
esac
