"""Матрёшка: настройка Keenetic / Netcraze через его API (RCI). Ничего существующего не трогает:
только создаёт новое подключение, новую политику и новую Wi-Fi-сеть.

Адрес, логин и пароль роутера — из МОИ_СЕРВЕРЫ.txt (КИНЕТИК_АДРЕС может быть http://192.168.1.1
или доменом KeenDNS вида https://имя.keenetic.pro — тогда роутер настраивается даже издалека).

  python scripts/keenetic.py check                 модель, прошивка, подключения + резервная копия настроек
  python scripts/keenetic.py tunnel                подключение «Matryoshka» из МОИ_КОНФИГИ/keenetic.conf
  python scripts/keenetic.py policy                политика «только через туннель» (стоп-кран)
  python scripts/keenetic.py wifi                  отдельная Wi-Fi-сеть, весь трафик которой идёт в матрёшку
  python scripts/keenetic.py host AA:BB:CC:DD:EE:FF  отдельное устройство (по MAC) — в матрёшку
  python scripts/keenetic.py save                  сохранить настройки в память роутера
  python scripts/keenetic.py status                состояние туннеля
  python scripts/keenetic.py down | up             выключить / включить туннель (проверка стоп-крана)
"""
import datetime
import hashlib
import http.cookiejar
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from matr_cfg import OUT_DIR, hide, need, read_cfg  # noqa: E402

cfg = read_cfg()
BASE = need(cfg, "КИНЕТИК_АДРЕС", "адрес роутера, например http://192.168.1.1").rstrip("/")
if not BASE.startswith("http"):
    BASE = "http://" + BASE
LOGIN = cfg.get("КИНЕТИК_ЛОГИН") or "admin"
PW = need(cfg, "КИНЕТИК_ПАРОЛЬ", "пароль от веб-интерфейса роутера")
STATE_FILE = os.path.join(OUT_DIR, "keenetic_state.json")
os.makedirs(OUT_DIR, exist_ok=True)

jar = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
EXTRA_SECRETS = []


def mask(text):
    text = hide(text, cfg)
    for s in EXTRA_SECRETS:
        text = text.replace(s, "<скрыто>")
    return re.sub(r"((?:private-key|preshared-key|psk|password)\s+)\S+", r"\1<скрыто>", text, flags=re.I)


def req(path, data=None):
    body = None if data is None else json.dumps(data).encode()
    r = urllib.request.Request(BASE + path, data=body,
                               headers={"Content-Type": "application/json"} if body else {})
    try:
        with opener.open(r, timeout=30) as resp:
            return resp.status, dict(resp.headers), resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read().decode("utf-8", "replace")
    except Exception as e:  # noqa: BLE001
        sys.exit(f"Роутер {BASE} не отвечает ({type(e).__name__}). Компьютер в сети этого роутера? "
                 f"Для KeenDNS: включён доступ к веб-интерфейсу из интернета?")


def login():
    code, hdr, _ = req("/auth")
    if code == 200:
        return
    if code != 401:
        sys.exit(f"Роутер ответил странно (HTTP {code}). Это точно Keenetic / Netcraze?")
    h = {k.lower(): v for k, v in hdr.items()}
    realm, chal = h.get("x-ndm-realm"), h.get("x-ndm-challenge")
    if not realm or not chal:
        sys.exit("Роутер не прислал данные для входа. Это точно Keenetic / Netcraze?")
    md5 = hashlib.md5(f"{LOGIN}:{realm}:{PW}".encode()).hexdigest()
    sha = hashlib.sha256((chal + md5).encode()).hexdigest()
    code, _, _ = req("/auth", {"login": LOGIN, "password": sha})
    if code != 200:
        sys.exit("Неверный логин или пароль роутера. Попроси человека проверить МОИ_СЕРВЕРЫ.txt.")


def cli(line, fatal=True, echo=True):
    """Одна строка командной строки Keenetic через /rci/ parse. Возвращает (ok, текст)."""
    code, _, body = req("/rci/", [{"parse": line}])
    ok, msgs, text = code == 200, [], ""
    try:
        j = json.loads(body)
        res = j[0].get("parse", j[0]) if isinstance(j, list) and j else j
        for st in (res.get("status", []) if isinstance(res, dict) else []):
            msgs.append(f"[{st.get('status')}] {st.get('message')}")
            if st.get("status") == "error":
                ok = False
        out = res.get("message") if isinstance(res, dict) else None
        text = "\n".join(out) if isinstance(out, list) else (out or "")
    except Exception:  # noqa: BLE001
        ok, text = False, body[:300]
    full = (text + ("\n" if text and msgs else "") + "\n".join(msgs)).strip()
    if echo:
        print("> " + mask(line)[:160])
        if full and not line.startswith("show running-config"):
            print("    " + mask(full).replace("\n", "\n    ")[:500])
    if not ok and fatal:
        sys.exit("ОСТАНОВЛЕНО: роутер вернул ошибку. В память ничего не сохранено, перезагрузка роутера вернёт как было.")
    return ok, full


def post(path, payload, label):
    code, _, body = req(path, payload)
    txt = mask(body)
    msgs = re.findall(r'"message": "([^"]*)"', txt)
    print(f"[{label}] " + (" | ".join(msgs)[:300] or f"HTTP {code}"))
    if code != 200 or '"error"' in txt:
        print(txt[:600])
        sys.exit(f"ОСТАНОВЛЕНО на шаге «{label}». В память ничего не сохранено.")


def get_json(path):
    code, _, body = req(path)
    try:
        return json.loads(body)
    except Exception:  # noqa: BLE001
        return {}


def running_config():
    _, text = cli("show running-config", fatal=False, echo=False)
    if "interface" not in text:
        j = get_json("/rci/show/running-config")
        msg = j.get("message") if isinstance(j, dict) else None
        text = "\n".join(msg) if isinstance(msg, list) else (msg or text)
    return text


def interfaces():
    j = get_json("/rci/show/interface")
    return j if isinstance(j, dict) else {}


def default_routes():
    j = get_json("/rci/show/ip/route")
    rows = j if isinstance(j, list) else j.get("route", []) if isinstance(j, dict) else []
    return sorted({r.get("interface", "?") for r in rows
                   if isinstance(r, dict) and r.get("destination") in ("0.0.0.0/0", "0.0.0.0")})


def load_state():
    if os.path.exists(STATE_FILE):
        return json.load(open(STATE_FILE, encoding="utf-8"))
    return {}


def save_state(st):
    json.dump(st, open(STATE_FILE, "w", encoding="utf-8"), ensure_ascii=False, indent=1)


def free_name(prefix, taken, start=0):
    n = start
    while f"{prefix}{n}" in taken:
        n += 1
    return f"{prefix}{n}"


def parse_conf(path):
    if not os.path.exists(path):
        sys.exit(f"Нет файла {path}. Сначала: python scripts/matr_ssh.py fetch")
    kv, section = {}, None
    for raw in open(path, encoding="utf-8"):
        line = raw.strip()
        if line.startswith("["):
            section = line.strip("[]").lower()
            continue
        if "=" in line and not line.startswith("#"):
            k, v = line.split("=", 1)
            kv[f"{section}.{k.strip()}"] = v.strip()
    return kv


# ------------------------------------------------------------------ команды
def cmd_check():
    login()
    v = get_json("/rci/show/version")
    model = v.get("model") or v.get("device") or "?"
    rel = v.get("release") or v.get("title") or "?"
    print(f"Роутер: {model}, прошивка {rel}")
    m = re.match(r"(\d+)\.(\d+)", str(rel))
    if m and (int(m.group(1)), int(m.group(2))) < (4, 2):
        print("ВНИМАНИЕ: прошивка старая. AmneziaWG на Keenetic — с 4.2 (лучше 4.3+). Обнови прошивку.")
    comps = json.dumps(v, ensure_ascii=False).lower()
    if "wireguard" not in comps:
        print("ЗАМЕТКА: в списке компонентов не видно WireGuard. Если создание туннеля упадёт — "
              "человеку: Управление → Параметры системы → Изменить набор компонентов → «WireGuard VPN» → Установить.")
    print("\nПодключения сейчас:")
    for name, i in sorted(interfaces().items()):
        if not isinstance(i, dict):
            continue
        t = i.get("type", "")
        if t in ("Port", "Switch", "AccessPoint", "WifiStation") or name.startswith(("GigabitEthernet", "FastEthernet")):
            continue
        print(f"  {name:<14} {t:<12} {i.get('description', ''):<24} {i.get('state', '')}")
    print("Основной выход в интернет сейчас:", ", ".join(default_routes()) or "?")
    rc = running_config()
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    path = os.path.join(OUT_DIR, f"keenetic_backup_{stamp}.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(rc)
    print(f"\nРезервная копия настроек: МОИ_КОНФИГИ/{os.path.basename(path)} (в кадр и в чат не показывать)")
    ipv6 = [ln.strip() for ln in rc.splitlines() if "ipv6" in ln.lower() and not ln.strip().startswith("!")]
    if ipv6:
        print(f"IPv6 в настройках есть (строк: {len(ipv6)}). Для новой Wi-Fi матрёшки он не включается, проверим после.")


def asc_try(ifname, kv):
    base = " ".join(kv[f"interface.{k}"] for k in ("Jc", "Jmin", "Jmax", "S1", "S2", "H1", "H2", "H3", "H4"))
    ok, _ = cli(f'interface {ifname} wireguard asc {base} 0 0 "" "" "" "" ""', fatal=False)
    if ok:
        return
    ok, _ = cli(f"interface {ifname} wireguard asc {base}", fatal=False)
    if not ok:
        sys.exit("ОСТАНОВЛЕНО: роутер не принял параметры AmneziaWG. Нужна прошивка 4.2+ (лучше свежая стабильная).")


def cmd_tunnel(conf_path):
    login()
    st = load_state()
    ifs = interfaces()
    if st.get("tunnel") in ifs:
        sys.exit(f"Туннель матрёшки уже есть: {st['tunnel']}. Повторно не создаю.")
    kv = parse_conf(conf_path)
    for k in ("interface.PrivateKey", "interface.Address", "peer.PublicKey", "peer.Endpoint", "interface.Jc"):
        if k not in kv:
            sys.exit(f"В {conf_path} нет {k} — это не конфиг матрёшки.")
    EXTRA_SECRETS.extend([kv["interface.PrivateKey"], kv.get("peer.PresharedKey", "-"), kv["peer.Endpoint"]])
    ifname = free_name("Wireguard", ifs)
    before = default_routes()
    addr = kv["interface.Address"].split("/")[0]
    host, port = kv["peer.Endpoint"].rsplit(":", 1)
    print(f"Создаю {ifname} «Matryoshka»")
    cli(f"interface {ifname}")
    cli(f"interface {ifname} description Matryoshka")
    cli(f"interface {ifname} security-level public")
    cli(f"interface {ifname} ip address {addr} 255.255.255.255")
    cli(f"interface {ifname} ip mtu {kv.get('interface.MTU', '1280')}")
    cli(f"interface {ifname} ip tcp adjust-mss pmtu")
    cli(f"interface {ifname} wireguard private-key {kv['interface.PrivateKey']}")
    asc_try(ifname, kv)
    peer = {"key": kv["peer.PublicKey"], "endpoint": {"address": f"{host}:{port}"},
            "keepalive-interval": {"interval": 25},
            "allow-ips": [{"address": "0.0.0.0", "mask": "0.0.0.0"}]}
    if kv.get("peer.PresharedKey"):
        peer["preshared-key"] = kv["peer.PresharedKey"]
    post(f"/rci/interface/{ifname}", {"wireguard": {"peer": peer}}, "собеседник (вход)")
    prios = [int(x) for x in re.findall(r"^\s*ip global (\d+)\s*$", running_config(), re.M)]
    prio = max(1, (min(prios) // 2) if prios else 100)
    post(f"/rci/interface/{ifname}", {"ip": {"global": {"priority": prio}}}, f"разрешить для политик (приоритет {prio})")
    post(f"/rci/interface/{ifname}", {"up": True}, "включить")
    st["tunnel"] = ifname
    save_state(st)
    after = default_routes()
    if before and after and before != after:
        print(f"ВНИМАНИЕ: основной выход сменился ({before} -> {after}). Дом не должен уходить в туннель — "
              f"проверь и выключи туннель: python scripts/keenetic.py down")
    wait_handshake(ifname)


def wait_handshake(ifname):
    for i in range(10):
        time.sleep(3)
        s = get_json(f"/rci/show/interface/{ifname}")
        peers = (s.get("wireguard") or {}).get("peer") or [{}]
        p = peers[0] if isinstance(peers, list) else peers
        if p.get("online") or (p.get("rxbytes") or 0) > 0:
            print(f"OK: туннель {ifname} поднят, рукопожатие с входом есть (прошло {3 * (i + 1)} с)")
            return True
    print("Рукопожатия пока нет. Проверь: на входе `python scripts/matr_ssh.py status`, "
          "время на роутере верное, провайдер не режет UDP. Ничего не сохранено в память.")
    return False


def policy_block(rc, name):
    out, inside = [], False
    for ln in rc.splitlines():
        if ln.startswith(f"ip policy {name}"):
            inside = True
            out.append(ln)
            continue
        if inside:
            if ln.startswith(" "):
                out.append(ln)
            else:
                break
    return out


def cmd_policy():
    login()
    st = load_state()
    tun = st.get("tunnel")
    if not tun:
        sys.exit("Сначала туннель: python scripts/keenetic.py tunnel")
    rc = running_config()
    if st.get("policy") and f"ip policy {st['policy']}" in rc:
        print(f"Политика уже есть: {st['policy']}")
    else:
        taken = set(re.findall(r"^ip policy (\S+)", rc, re.M))
        pol = free_name("Policy", taken)
        cli(f"ip policy {pol}")
        cli(f"ip policy {pol} description Matryoshka")
        cli(f"ip policy {pol} permit global {tun}")
        st["policy"] = pol
        save_state(st)
    pol = st["policy"]
    block = policy_block(running_config(), pol)
    print("Политика сейчас:\n  " + "\n  ".join(block))
    other = [ln for ln in block if "permit" in ln and tun not in ln and " no " not in f" {ln} "]
    if other:
        print("ВНИМАНИЕ: в политике есть другие подключения — при падении туннеля трафик уйдёт мимо. "
              "Человеку: Интернет → Приоритеты подключений → Matryoshka → оставить галочку только у Matryoshka.")
    else:
        print(f"OK: в политике {pol} только туннель {tun}. Упал туннель — у устройств нет интернета (стоп-кран).")


def cmd_wifi():
    login()
    st = load_state()
    pol = st.get("policy")
    if not pol:
        sys.exit("Сначала политика: python scripts/keenetic.py policy")
    ssid = cfg.get("WIFI_ИМЯ") or "Matryoshka"
    psk = need(cfg, "WIFI_ПАРОЛЬ", "пароль новой Wi-Fi сети, от 8 символов")
    if len(psk) < 8:
        sys.exit("WIFI_ПАРОЛЬ должен быть от 8 символов.")
    if not re.fullmatch(r"[A-Za-z0-9_\-]{1,32}", ssid):
        sys.exit("WIFI_ИМЯ — латиницей, без пробелов (телевизоры плохо понимают кириллицу).")
    EXTRA_SECRETS.append(psk)
    ifs = interfaces()
    rc = running_config()
    if st.get("bridge") in ifs:
        sys.exit(f"Сеть матрёшки уже есть: {st['bridge']}")
    br = free_name("Bridge", ifs, start=1)
    net = next((f"192.168.{n}" for n in range(77, 100) if f"192.168.{n}." not in rc), None)
    if not net:
        sys.exit("Не нашёл свободную подсеть 192.168.77–99.x")
    pool = "matryoshka"
    print(f"Создаю сегмент {br} ({net}.0/24) и Wi-Fi «{ssid}»")
    for line in [f"interface {br}", f"interface {br} description {ssid}",
                 f"interface {br} security-level protected",
                 f"interface {br} ip address {net}.1 255.255.255.0", f"interface {br} up",
                 f"ip dhcp pool {pool}", f"ip dhcp pool {pool} range {net}.10 {net}.250",
                 f"ip dhcp pool {pool} bind {br}", f"ip dhcp pool {pool} dns-server 1.1.1.1 9.9.9.9",
                 f"ip dhcp pool {pool} lease 25200", f"ip dhcp pool {pool} enable",
                 f"ip nat {br}", f"ip hotspot policy {br} {pol}"]:
        cli(line)
    st["bridge"] = br
    save_state(st)
    wl = "matryoshka"
    ok_wifi = True
    steps = [[f"mws wlan {wl}"], [f"mws wlan {wl} band 0"], None, [f"mws wlan {wl} bind {br}"],
             [f"mws wlan {wl} ssid name {ssid}"],
             [f"mws wlan {wl} encryption wpa2+3", f"mws wlan {wl} encryption wpa2"],
             [f"mws wlan {wl} wpa psk {psk}"], [f"mws wlan {wl} enable"]]
    for variants in steps:
        if variants is None:  # 5 ГГц есть не у всех моделей (Runner, Start — только 2,4)
            if not cli(f"mws wlan {wl} band 1", fatal=False)[0]:
                print("    (5 ГГц у этой модели нет — сеть будет только на 2,4 ГГц, это нормально)")
            continue
        if not any(cli(v, fatal=False)[0] for v in variants):
            ok_wifi = False
            break
    if ok_wifi:
        print(f"OK: Wi-Fi «{ssid}» включена. Всё, что к ней подключено, идёт только через матрёшку.")
    else:
        print(f"Сегмент {br} создан, но Wi-Fi эта модель через API не включает. Человеку (1 минута): "
              f"Мои сети и Wi-Fi → Сегменты → «{ssid}» → включить Wi-Fi 2,4 и 5 ГГц, имя {ssid}, пароль из МОИ_СЕРВЕРЫ.txt.")
    v6 = [ln.strip() for ln in running_config().splitlines() if "ipv6" in ln.lower() and br in ln]
    print("IPv6 в новой сети: " + ("ЕСТЬ — выключи в настройках сегмента: " + "; ".join(v6) if v6 else "нет (так и надо)"))


def cmd_host(mac):
    login()
    st = load_state()
    pol = st.get("policy")
    if not pol:
        sys.exit("Сначала политика: python scripts/keenetic.py policy")
    if not re.fullmatch(r"([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}", mac or ""):
        sys.exit("Нужен MAC вида aa:bb:cc:dd:ee:ff (видно в Список устройств).")
    ok, _ = cli(f"ip hotspot host {mac.lower()} policy {pol}", fatal=False)
    if ok:
        print(f"OK: {mac} теперь ходит только через матрёшку. DNS у такого устройства — роутера; "
              f"для чистоты лучше подключить его к Wi-Fi матрёшки.")
    else:
        print("Через API не вышло. Человеку: Интернет → Приоритеты подключений → Применение политик → "
              "перетащить устройство в Matryoshka.")


def cmd_save():
    login()
    cli("system configuration save")
    print("OK: настройки записаны в память роутера.")


def cmd_status():
    login()
    st = load_state()
    tun = st.get("tunnel")
    if not tun:
        sys.exit("Туннель матрёшки ещё не создан.")
    s = get_json(f"/rci/show/interface/{tun}")
    peers = (s.get("wireguard") or {}).get("peer") or [{}]
    p = peers[0] if isinstance(peers, list) else peers
    print(f"{tun}: состояние {s.get('state')}, связь {s.get('link')}, вход на связи: {p.get('online')}, "
          f"принято {p.get('rxbytes')} байт, отправлено {p.get('txbytes')} байт")
    print("Политика:", st.get("policy"), "| сеть:", st.get("bridge"))


def cmd_updown(up):
    login()
    tun = load_state().get("tunnel")
    if not tun:
        sys.exit("Туннель матрёшки ещё не создан.")
    cli(f"interface {tun} {'up' if up else 'down'}")
    print("Туннель включён." if up else "Туннель выключен. Устройства в матрёшке сейчас должны остаться БЕЗ интернета — "
          "это и есть стоп-кран. Проверь на телефоне, потом: python scripts/keenetic.py up")


def main():
    a = [x for x in sys.argv[1:] if not x.startswith("--")]
    if not a:
        print(__doc__)
        return
    c = a[0]
    if c == "check":
        cmd_check()
    elif c == "tunnel":
        cmd_tunnel(a[1] if len(a) > 1 else os.path.join(OUT_DIR, "keenetic.conf"))
    elif c == "policy":
        cmd_policy()
    elif c == "wifi":
        cmd_wifi()
    elif c == "host" and len(a) > 1:
        cmd_host(a[1])
    elif c == "save":
        cmd_save()
    elif c == "status":
        cmd_status()
    elif c in ("up", "down"):
        cmd_updown(c == "up")
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
