"""Матрёшка: агент работает с серверами только через этот файл.

Пароли и адреса берутся из МОИ_СЕРВЕРЫ.txt. Пароли не печатаются никогда,
адреса серверов в выводе заменены на [вход] / [выход] (флаг --show-ip показывает настоящие).

Запускать из папки Матрёшки:
  python scripts/matr_ssh.py check     оба сервера: доступ, система, память
  python scripts/matr_ssh.py exit      настроить ВЫХОД (заграница)
  python scripts/matr_ssh.py relay     перенести ключ связки с выхода на вход
  python scripts/matr_ssh.py entry     настроить ВХОД (РФ)
  python scripts/matr_ssh.py fetch     скачать конфиги клиентов в папку МОИ_КОНФИГИ
  python scripts/matr_ssh.py status    проверка всей цепочки
  python scripts/matr_ssh.py all       exit + relay + entry + fetch подряд
  python scripts/matr_ssh.py add ИМЯ   ещё один клиент (телефон мамы, ноутбук) -> МОИ_КОНФИГИ/ИМЯ.conf
  python scripts/matr_ssh.py run entry|exit "команда"   разовая команда для починки
  python scripts/matr_ssh.py remove entry|exit          снести матрёшку с сервера
Добавь --force, чтобы перенастроить уже настроенный сервер с нуля.
"""
import base64
import datetime
import os
import re
import shlex
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from matr_cfg import HERE, OUT_DIR, hide, need, read_cfg  # noqa: E402

try:
    import paramiko
except ImportError:
    sys.exit("Нет модуля paramiko. Установи: python -m pip install paramiko  — и запусти ещё раз.")

SCRIPT = os.path.join(HERE, "matryoshka.sh")
ROLE = {"entry": "ВХОД", "exit": "ВЫХОД"}
NAME = {"entry": "ВХОД (РФ)", "exit": "ВЫХОД (заграница)"}
cfg = read_cfg()
SHOW_IP = "--show-ip" in sys.argv
FORCE = "--force" in sys.argv
ARGS = [a for a in sys.argv[1:] if not a.startswith("--")]
LOG = os.path.join(OUT_DIR, "журнал.txt")
os.makedirs(OUT_DIR, exist_ok=True)


def mask(text):
    text = hide(text, cfg)
    if not SHOW_IP:
        for role, label in (("entry", "[вход]"), ("exit", "[выход]")):
            for key in (f"{ROLE[role]}_IP", f"_EGRESS_{role}"):
                ip = cfg.get(key)
                if ip:
                    text = re.sub(r"(?<![\d.])" + re.escape(ip) + r"(?![\d])", label, text)
    return text


def log(text):
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(hide(text, cfg))


def connect(role):
    p = ROLE[role]
    ip = need(cfg, f"{p}_IP", f"адрес сервера «{p.lower()}»")
    if ":" in ip:
        sys.exit(f"{NAME[role]}: в файле адрес IPv6 ({'адрес скрыт' if not SHOW_IP else ip}). Значит, у сервера НЕТ обычного "
                 f"IPv4-адреса, а роутеры и российские сайты работают по IPv4. Человеку: добавить IPv4 в панели "
                 f"хостера (или взять тариф с IPv4) и вписать новый адрес в МОИ_СЕРВЕРЫ.txt. Дальше не продолжай.")
    user = cfg.get(f"{p}_ЛОГИН") or "root"
    pw = cfg.get(f"{p}_ПАРОЛЬ") or None
    key = cfg.get(f"{p}_КЛЮЧ") or None
    if not pw and not key:
        need(cfg, f"{p}_ПАРОЛЬ", f"пароль сервера «{p.lower()}» из письма хостера")
    port = int(cfg.get(f"{p}_ПОРТ_SSH") or 22)
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        c.connect(ip, port=port, username=user, password=pw, key_filename=key, timeout=25,
                  banner_timeout=60, auth_timeout=60, look_for_keys=False, allow_agent=False)
    except paramiko.AuthenticationException:
        sys.exit(f"{NAME[role]}: неверный логин или пароль. Попроси человека проверить МОИ_СЕРВЕРЫ.txt.")
    except Exception as e:  # noqa: BLE001
        sys.exit(f"{NAME[role]}: не подключиться по SSH ({type(e).__name__}: {mask(str(e))}). "
                 f"Сервер включён? Адрес верный? Подожди 2 минуты после покупки и повтори.")
    return c, user, pw


def run(role, command, stream=True, quiet_ok=False, log_out=True):
    c, user, pw = connect(role)
    full = command if user == "root" else f"sudo -S -p '' bash -c {shlex.quote(command)}"
    stdin, stdout, _ = c.exec_command(full)
    if user != "root":
        stdin.write((pw or "") + "\n")
        stdin.flush()
    stdin.channel.shutdown_write()
    ch = stdout.channel
    chunks = []
    stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log(f"\n##### {stamp} {NAME[role]}: {command[:120] if 'base64' not in command else '(загрузка скрипта)'}\n")
    while True:
        got = False
        while ch.recv_ready():
            data = ch.recv(65536).decode("utf-8", "replace")
            chunks.append(data)
            if log_out:
                log(data)
            if stream:
                print(mask(data), end="", flush=True)
            got = True
        while ch.recv_stderr_ready():
            data = ch.recv_stderr(65536).decode("utf-8", "replace")
            chunks.append(data)
            log(data)
            if stream:
                print(mask(data), end="", flush=True)
            got = True
        if ch.exit_status_ready() and not ch.recv_ready() and not ch.recv_stderr_ready():
            break
        if not got:
            time.sleep(0.15)
    code = ch.recv_exit_status()
    c.close()
    if code != 0 and not quiet_ok:
        print(f"\n[{NAME[role]}] команда завершилась с ошибкой (код {code}). Полный вывод: МОИ_КОНФИГИ/журнал.txt")
    return code, "".join(chunks)


def push(role, data: bytes, remote, mode="600"):
    b64 = base64.b64encode(data).decode()
    d = os.path.dirname(remote)
    code, out = run(role, f"umask 077; mkdir -p {d} && echo {b64} | base64 -d > {remote} && chmod {mode} {remote}",
                    stream=False)
    if code != 0:
        sys.exit(f"{NAME[role]}: не удалось положить файл {remote}: {mask(out)[:300]}")


def push_script(role):
    data = open(SCRIPT, "rb").read().replace(b"\r\n", b"\n")
    push(role, data, "/root/matryoshka/matryoshka.sh", "700")


def egress(role):
    try:
        code, out = run(role, "curl -4 -fsS --max-time 10 https://api.ipify.org || true", stream=False, quiet_ok=True)
    except SystemExit:
        return ""
    ip = out.strip().splitlines()[-1].strip() if out.strip() else ""
    if re.fullmatch(r"\d+\.\d+\.\d+\.\d+", ip):
        cfg[f"_EGRESS_{role}"] = ip
        return ip
    return ""


def cmd_check():
    probe = ("set +e; . /etc/os-release; echo \"Система: $PRETTY_NAME\"; "
             "v=$(systemd-detect-virt 2>/dev/null); echo \"Виртуализация: ${v:-?}\"; "
             "echo \"Память: $(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo) МБ, ядер: $(nproc)\"; "
             "echo \"Ядро: $(uname -r)\"; [ -c /dev/net/tun ] && echo 'TUN: есть' || echo 'TUN: НЕТ'")
    bad = False
    for role in ("exit", "entry"):
        print(f"\n=== {NAME[role]}")
        code, out = run(role, probe)
        if code != 0:
            bad = True
        if "ubuntu" not in out.lower() and "debian" not in out.lower():
            print("  ВНИМАНИЕ: нужен Debian 11–13 или Ubuntu 22.04/24.04. Переустанови систему в панели хостера (лучше Debian 13).")
            bad = True
        if re.search(r"Виртуализация: (openvz|lxc)", out):
            print("  ВНИМАНИЕ: OpenVZ/LXC — туннель может не встать. Лучше тариф KVM.")
        ip = egress(role)
        conf_ip = cfg.get(f"{ROLE[role]}_IP")
        if ip and conf_ip and ip != conf_ip:
            print(f"  Заметка: сервер выходит в интернет с другого адреса ({mask(ip)}), учту это.")
    print("\nПроверка закончена." + (" Есть замечания выше." if bad else " Можно ставить: python scripts/matr_ssh.py all"))


def cmd_exit():
    entry_ip = egress("entry") or need(cfg, "ВХОД_IP", "адрес входа")
    exit_ip = need(cfg, "ВЫХОД_IP", "адрес выхода")
    print(f"=== Настраиваю {NAME['exit']} (3–10 минут)")
    push_script("exit")
    env = f"ENTRY_IP={entry_ip} EXIT_IP={exit_ip}" + (" FORCE=1" if FORCE else "")
    code, _ = run("exit", f"{env} bash /root/matryoshka/matryoshka.sh exit")
    if code != 0:
        sys.exit(1)


def cmd_relay():
    code, out = run("exit", "cat /root/matryoshka/entry-uplink.conf", stream=False, log_out=False)
    if code != 0 or "[Peer]" not in out:
        sys.exit("На выходе нет ключа связки. Сначала: python scripts/matr_ssh.py exit")
    push("entry", out.encode(), "/root/matryoshka/entry-uplink.conf")
    print("OK: ключ связки перенесён с выхода на вход (на экран не выводился)")


def cmd_entry():
    entry_ip = need(cfg, "ВХОД_IP", "адрес входа")
    clients = cfg.get("КЛИЕНТЫ") or "keenetic phone pc"
    if not re.fullmatch(r"[A-Za-z0-9_\- ]+", clients):
        sys.exit("КЛИЕНТЫ в МОИ_СЕРВЕРЫ.txt — только латиница через пробел, например: keenetic phone pc")
    print(f"=== Настраиваю {NAME['entry']} (3–10 минут)")
    push_script("entry")
    env = f"ENTRY_IP={entry_ip} CLIENTS={shlex.quote(clients)}" + (" FORCE=1" if FORCE else "")
    code, _ = run("entry", f"{env} bash /root/matryoshka/matryoshka.sh entry")
    if code != 0:
        sys.exit(1)


def cmd_fetch():
    code, out = run("entry", "ls /root/matryoshka/clients", stream=False)
    names = [n.strip() for n in out.split() if n.strip().endswith(".conf")]
    if code != 0 or not names:
        sys.exit("На входе нет конфигов клиентов. Сначала: python scripts/matr_ssh.py entry")
    for n in names:
        if not re.fullmatch(r"[A-Za-z0-9_\-]+\.conf", n):
            continue
        code, body = run("entry", f"cat /root/matryoshka/clients/{n}", stream=False, log_out=False)
        if code == 0 and "[Interface]" in body:
            path = os.path.join(OUT_DIR, n)
            with open(path, "w", encoding="utf-8", newline="\n") as f:
                f.write(body)
            print(f"OK: {os.path.relpath(path, os.path.dirname(OUT_DIR))}")
    print("Конфиги лежат в папке МОИ_КОНФИГИ. Это ключи от VPN: никому не пересылать, в кадр не показывать.")


def cmd_status():
    for role in ("exit", "entry"):
        egress(role)
    for role in ("exit", "entry"):
        print(f"\n######## {NAME[role]}")
        run(role, "/usr/local/sbin/matryoshka status")


def cmd_add(name):
    if not re.fullmatch(r"[A-Za-z0-9_\-]{1,32}", name or ""):
        sys.exit("Имя клиента — латиница, цифры, - или _. Пример: python scripts/matr_ssh.py add mama")
    code, _ = run("entry", f"/usr/local/sbin/matryoshka add-client {name}")
    if code == 0:
        cmd_fetch()


def main():
    if not ARGS:
        print(__doc__)
        return
    cmd = ARGS[0]
    if cmd == "check":
        cmd_check()
    elif cmd == "exit":
        cmd_exit()
    elif cmd == "relay":
        cmd_relay()
    elif cmd == "entry":
        cmd_entry()
    elif cmd == "fetch":
        cmd_fetch()
    elif cmd == "status":
        cmd_status()
    elif cmd == "all":
        cmd_exit()
        cmd_relay()
        cmd_entry()
        cmd_fetch()
        print("\nГОТОВО. Дальше: роутер (python scripts/keenetic.py check) или файл phone.conf в приложение AmneziaVPN.")
    elif cmd == "add" and len(ARGS) > 1:
        cmd_add(ARGS[1])
    elif cmd == "run" and len(ARGS) > 2 and ARGS[1] in ROLE:
        egress(ARGS[1])
        run(ARGS[1], ARGS[2])
    elif cmd == "remove" and len(ARGS) > 1 and ARGS[1] in ROLE:
        run(ARGS[1], "/usr/local/sbin/matryoshka remove")
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
